<?php
declare(strict_types=1);
session_start();
$config = require __DIR__ . '/../config/config.php';
spl_autoload_register(function (string $class): void {
  $path = __DIR__ . '/../app/' . $class . '.php';
  if (is_file($path)) require $path;
});
require __DIR__ . '/helpers.php';
$db = new Database($config['db']);
$userModel = new User($db);