<?php
declare(strict_types=1);
function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function redirect(string $to): never { header("Location: {$to}"); exit; }
function auth_user_id(): ?int { return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null; }
function require_auth(): void { if (!auth_user_id()) redirect('login.php'); }
function flash_set(string $key, string $message): void { $_SESSION['flash'][$key] = $message; }
function flash_get(string $key): ?string { $msg = $_SESSION['flash'][$key] ?? null; unset($_SESSION['flash'][$key]); return $msg; }