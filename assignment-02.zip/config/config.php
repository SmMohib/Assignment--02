<?php
declare(strict_types=1);
return ['db' => ['host' => '127.0.0.1', 'name' => 'assignment_auth', 'user' => 'root', 'pass' => '', 'charset' => 'utf8mb4']];