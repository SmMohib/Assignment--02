# Assignment 02: Authentication & Profile Management

## ⚠️ BEFORE SUBMISSION
### Name: [YOUR NAME HERE - REQUIRED]
### Email: [YOUR EMAIL HERE - REQUIRED]

## Features
✓ User Registration ✓ Login ✓ Dashboard ✓ Edit Profile ✓ Change Password ✓ Logout
✓ Password hashing ✓ SQL injection prevention ✓ Session security

## Installation
1. Import database.sql in phpMyAdmin
2. Place in htdocs/www folder
3. Visit: http://localhost/assignment-02/login.php
