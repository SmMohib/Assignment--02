<?php
declare(strict_types=1);
final class User {
  private PDO $pdo;
  public function __construct(Database $db) { $this->pdo = $db->pdo(); }
  public function findByEmail(string $email): ?array {
    $stmt = $this->pdo->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
    $stmt->execute(['email' => $email]);
    return $stmt->fetch() ?: null;
  }
  public function findPublicById(int $id): ?array {
    $stmt = $this->pdo->prepare('SELECT id, name, email, created_at FROM users WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $id]);
    return $stmt->fetch() ?: null;
  }
  public function findWithPasswordById(int $id): ?array {
    $stmt = $this->pdo->prepare('SELECT id, name, email, password FROM users WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $id]);
    return $stmt->fetch() ?: null;
  }
  public function emailTaken(string $email, ?int $ignoreUserId = null): bool {
    if ($ignoreUserId) {
      $stmt = $this->pdo->prepare('SELECT 1 FROM users WHERE email = :email AND id <> :id LIMIT 1');
      $stmt->execute(['email' => $email, 'id' => $ignoreUserId]);
    } else {
      $stmt = $this->pdo->prepare('SELECT 1 FROM users WHERE email = :email LIMIT 1');
      $stmt->execute(['email' => $email]);
    }
    return (bool)$stmt->fetch();
  }
  public function create(string $name, string $email, string $passwordHash): int {
    $stmt = $this->pdo->prepare('INSERT INTO users (name, email, password) VALUES (:name, :email, :password)');
    $stmt->execute(['name' => $name, 'email' => $email, 'password' => $passwordHash]);
    return (int)$this->pdo->lastInsertId();
  }
  public function updateProfile(int $id, string $name, string $email): void {
    $stmt = $this->pdo->prepare('UPDATE users SET name = :name, email = :email WHERE id = :id');
    $stmt->execute(['name' => $name, 'email' => $email, 'id' => $id]);
  }
  public function updatePassword(int $id, string $passwordHash): void {
    $stmt = $this->pdo->prepare('UPDATE users SET password = :password WHERE id = :id');
    $stmt->execute(['password' => $passwordHash, 'id' => $id]);
  }
}